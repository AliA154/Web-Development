let myChange = document.querySelector("p");
myChange.style.color = "darkblue";


let element = document.getElementById("head");


element.addEventListener("click", function() {
  
  alert("This is Just The Title!");
});
